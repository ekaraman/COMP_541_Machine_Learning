% Serike Cakmak
% 20131565 scakmak13@ku.edu.tr
%%%%%%%%%%%%%%%%%%%%% EIGENFACE ASSIGNMENT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all;
clear;
% training folder
trainimages = dir('training/*.jpg');
tsize = size(trainimages,1);
imcell = cell(1,tsize);
for i = 1:tsize % reading train images
  uint_img = imread(['training\' trainimages(i).name]);
  imcell{i}.doubleimg = im2double(uint_img); 
  d = imcell{i}.doubleimg; % double images in training folder
  imcell{i}.vecn2 = []; %img as vector of size n square
  v = zeros(size(imcell{i}.vecn2));
  v = imcell{i}.vecn2; 
  dsize = size(d,1);
  for j = 1:dsize
      v = [v d(j,:)]; 
  end
  imcell{i}.vecn2 = v; %n square size  vector
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TRAINING PHASE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K = size(imcell,2); %col num = 90 (number of train images)
Mean = 0;
for i=1:K
   X(i,:) =  imcell{i}.vecn2;
   Mean = Mean + X(i,:);
end
Mean = Mean * (1/K);
for i=1:K
   X(i,:) =  imcell{i}.vecn2;
   X(i,:) = X(i,:) - Mean; %mean normalized X vector to compute covarience matrix   
end
 
CMat = (X*X') * (1/K); %covariance matrix C
[eigenvalues,eigenvectors] = eig(CMat); %eigenvalues and eigenvectors of CMat
for k=1:K
   ev(k) = eigenvectors(k,k); %ev = eigenvalues
end
[sorted, indices] = sort(ev,'descend'); %sort
EigenVal = sorted; %sorted eigenvalues
for k = 1:K
  ev2(:,k) = eigenvalues(:,indices(:,k)); %sort
end
for i = 1:K
  v = X'*ev2(:,i);
  EigenVec(:,i) = v/norm(v); %reduced eigenvectors
end

%%%%%%%%%%%%%%%%%%%%%%%%%% CALCULATING COEFFICIENTS %%%%%%%%%%%%%%%%%%%%%%%
sumEigVal = sum(EigenVal);
sum = 0;
M = 1;
for M = 1:90
    if sum >= (sumEigVal*0.97)
        break;
    else
        sum = sum + EigenVal(M);
    end
end
bestM = M; %finding best M value

coeff = zeros(1,M); % bm coefficients calculation
for i = 1:K 
    for j=1:K
        NN = (imcell{i}.vecn2 - Mean);
        dotProd = dot(NN,EigenVec(:,j));
        coeff(j) = dotProd; 
    end
    imcell{i}.coefficients = coeff;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TEST PHASE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
testimages = dir('test/*.jpg');
tesize = size(testimages,1);
imcell2 = cell(1,tesize);
[filename,PathName] = uigetfile('test/*.jpg','Select the test image from test folder');
%[filename, user_canceled] = imgetfile;
[pathstr, name, ext] = fileparts(filename)

for i = 1:tesize % read test images
  uint_img2 = imread(['test\' testimages(i).name]);
  imcell2{i}.doubleimg = im2double(uint_img2); 
  d2 = imcell2{i}.doubleimg;
  imcell2{i}.vecn2 = [];
  v2 = zeros(size(imcell2{i}.vecn2));
  v2 = imcell2{i}.vecn2;
  d2size = size(d2,1);
  for j=1:d2size
      v2 = [v2 d2(j,:)]; 
  end
  imcell2{i}.vecn2 = v2; % n square size vector
end

for i=1:tesize
    Vecn2 = imcell2{i}.vecn2 - Mean;
    for j=1:K
        dotProd = dot(Vecn2,EigenVec(:,j));
        coeff(j) = dotProd; % bm values
    end
    imcell2{i}.coefficients = coeff;
    if testimages(i).name == strcat(name,ext) 
        testImg = imcell2{i}; % choosing image to test from the user
    end
end

L=size(Vecn2,2);
img = zeros(L,1);
for i=1:bestM
    tc = testImg.coefficients(i);
    egv = EigenVec(:,i);
    img = img + (tc)*(egv);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  MATCH PHASE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:K
    sumb(i) = 0;
    for j=1:bestM
        c = imcell{i}.coefficients(j);
        ct = testImg.coefficients(j);
        sumb(i) = sumb(i) + ((c-ct)*(c-ct))/EigenVal(j);
    end
end

figure(1);
subplot(1,4,1);
imshow(testImg.doubleimg); % test image
stit = sprintf('INPUT IMAGE\n');
title(stit);
for i=1:3 % best 3 matches
    [B, indices] = sort(sumb);
    subplot(1,4,i+1);
    imshow(imcell{indices(i)}.doubleimg);
    if i == (tesize + 1) / 2 || i == (tesize / 2)
        str = sprintf('BEST 3 MATCHES FROM LEFT TO RIGHT \n');
        str = [str num2str(i)];
        title(str);
    else 
        str = sprintf('\n');
        str = [str num2str(i)];
        title(str);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FINISH %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%