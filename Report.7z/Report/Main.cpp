#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>

using namespace cv;
using namespace std;

//Read original image

Mat readImage(String fileName) {
	Mat image = imread(fileName);
	if( image.data ) {
		cout << "Read image successfully..." << std::endl;
		return image;	
	}
	else {
		cout << "Could not open or find the image! Pls, check image name..." << std::endl;
		getchar();
		exit(1);
	}
}

//Convert RGB image to YCrCb
Mat convertToYCC (Mat imageRGB) {
	Mat imageYCC = Mat(imageRGB.size(),imageRGB.type());
	cvtColor(imageRGB, imageYCC, CV_BGR2YCrCb);
	if( imageYCC.data ) { 
		cout << "RGB image converted to YCrCb..." << std::endl;
		return imageYCC;	
	}
	else {
		cout << "Could not convert RGB image to YCrCb" << std::endl;
		getchar();
		exit(1);
	}
	
}

//Modulo division for image boundaries
int mod (int a, int b)
{
   if(b < 0)
     return mod(-a, -b);   
   int ret = a % b;
   if(ret < 0)
     ret+=b;
   return ret;
}

// Box Filter
Mat myBoxFilter (Mat I, int boxSize){
	
	Mat ISmooth = I.clone();

	Mat I_S_BGR = Mat(I.size(),I.type());

	int nRows = I.rows;
	int nCols = I.cols;

	int k;

	double edge = boxSize / 2;
	int filterEdge = floor(edge);

	int x;
	int y;


	for (int i = 0; i < nRows; i++) {
		for (int j = 0; j < nCols; j++) {
			k = 0;
			for(int filterX = 0; filterX < boxSize; filterX++) {
				for(int filterY = 0; filterY < boxSize; filterY++) {
					x = mod((i + filterX - filterEdge), nRows);
					y = mod ((j + filterY - filterEdge), nCols);
					k +=  I.at<Vec3b>(x,y)[0];
				}
			}
			ISmooth.at<Vec3b>(i,j)[0] = k / (boxSize * boxSize); 
		}
	}

	cvtColor(ISmooth, I_S_BGR, CV_YCrCb2BGR);
	return I_S_BGR;

}

//Median Filter

Mat myMedianFilter (Mat I, int boxSize){
	Mat ISmooth = I.clone();

	Mat I_S_BGR = Mat(I.size(),I.type());

	int nRows = I.rows;
	int nCols = I.cols;

	int k;

	double edge = boxSize / 2;
	int filterEdge = floor(edge);

	int x;
	int y;

	vector<uchar> vPixel (boxSize * boxSize);
	
	for (int i = 0; i < nRows; i++) {
		for (int j = 0; j < nCols; j++) {
			k = 0;
			for(int filterX = 0; filterX < boxSize; filterX++) {
				for(int filterY = 0; filterY < boxSize; filterY++) {
					x = mod((i + filterX - filterEdge), nRows);
					y = mod ((j + filterY - filterEdge), nCols);
					vPixel [k] = I.at<Vec3b>(x,y)[0];
					k += 1;
				}
			}
			//Find median
			nth_element(vPixel.begin(), vPixel.begin() + vPixel.size()/2, vPixel.end());
			//Assign median to YCrCb image
			ISmooth.at<Vec3b>(i,j)[0] = vPixel[vPixel.size()/2];
		}
	}

	cvtColor(ISmooth, I_S_BGR, CV_YCrCb2BGR);
	return I_S_BGR;
}

//Draws Histogram

Mat drawMyHist (Mat I) {
	//Find maximum value in Mat Histogram 
	double max;
	Point pMax;
	minMaxLoc(I,NULL,&max,NULL,&pMax);

	Mat hisGraph = Mat::ones(256, 256, CV_8UC3);
	int nRowsHis;
	nRowsHis = hisGraph.rows;
	// Drawing 
	for (int j = 0 ; j < 255; j++) {
		line(hisGraph, 
			Point(j, nRowsHis), 
			Point(j, nRowsHis - (I.at<int>(j) * nRowsHis/max)), 
			Scalar(10,100,245), 1, 8, 0);
	}
	return hisGraph;
}

//Calculate Histogram Values

Mat calcHist(Mat I) {

	//Initialize Mat type Histogram matrix which stores number of times that indexed pixel value occurs in the image.
	Mat	histogram = Mat::zeros(1, 256, CV_32SC1);
	
	int nRows = I.rows;
	int nCols = I.cols;

	// Calculate histogram
	for (int i = 0; i < nRows; i++) {
		for (int j = 0; j < nCols; j++) {
			histogram.at<int>(I.at<Vec3b>(i,j)[0]) += 1;
		}
	}

	return histogram;
}

//OpenCV built in Histogram Calculation

Mat opencvHist(Mat I) {

	// Set the number of bins
	int histSize = 256;

	 // Set the ranges ( used B,G,R range since source image is BGR) )
	float range[] = { 0, 256 } ;
	const float* histRange = { range };

	bool uniform = true;
	bool accumulate = false;

	// Separate the image in 3 places ( Y, Cb and Cr )
	vector<Mat> ycc_planes;
	split( I, ycc_planes );

	Mat y_hist;

	// Compute the histogram fo Y channel
	calcHist( &ycc_planes[0], 1, 0, Mat(), y_hist, 1, &histSize, &histRange, uniform, accumulate );
	
	// Draw the histogram for Y channel
	int hist_w = 512; 
	int hist_h = 400;
	int bin_w = cvRound( (double) hist_w/histSize );
	Mat histImage( hist_h, hist_w, CV_8UC3, Scalar( 0,0,0) );

	// Normalize the result to [ 0, histImage.rows ]
	normalize(y_hist, y_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat() );

	/// Draw for Y channel
	for( int i = 1; i < histSize; i++ )
	{
		line( histImage, Point( bin_w*(i-1), hist_h - cvRound(y_hist.at<float>(i-1))) ,
						 Point( bin_w*(i), hist_h - cvRound(y_hist.at<float>(i)) ),
						 Scalar(10,100,245), 2, 8, 0  );
	}
	return histImage;
}

Mat myHistEqu(Mat ycc) {

	//Find intesity values
	Mat histogram;
	histogram = calcHist(ycc);

	//Find probability values for each pixel value
	int nRows = ycc.rows;
	int nCols = ycc.cols;
	int imageSize = nRows * nCols;

	double prob[256];
	for(int i=0; i<256; i++) {
		prob[i] = (double) histogram.at<int>(i) / imageSize;
	}

	//Find cumulative probabilities
	int cumuPoss[256];
	cumuPoss[0] = histogram.at<int>(0);
	for(int i=1; i<256; i++) {
		cumuPoss[i]= histogram.at<int>(i) + cumuPoss[i-1];
	}
	//Scale cumulative values. scaleVal = (K - 1) / M * N
	double scaleVal = (double) 255/(nRows * nCols);
	int scaledCum[256];
	for(int i=0; i<256; i++) {
		scaledCum[i] = cvRound((double)cumuPoss[i] * scaleVal); // scaling (finding Sk values)
	}
	//Calculate scaled cumulative probability values for histogram
	double scaledCumProb[256];
	for(int i=0; i<256; i++) {
		scaledCumProb[i]=0;
	}

	for(int i=0; i<256; i++) {
		scaledCumProb[scaledCum[i]] += prob[i]; // sk2 values for histogram
	}

	//Find equalized his values
	int equHist[256];
	for(int i=0; i<256; i++)
		equHist[i] = cvRound(scaledCumProb[i]*255);

	Mat equalImg = ycc.clone();
	for(int y=0; y < nRows; y++) {
		for(int x=0; x < nCols; x++) {
			equalImg.at<Vec3b>(y,x)[0] = saturate_cast<uchar>(scaledCum[ycc.at<Vec3b>(y,x)[0]]);
		}
	}

	// Convert equalized YCrCb image to BGR image
	Mat equalBGR;
	cvtColor(equalImg, equalBGR , CV_YCrCb2BGR); 

	Mat graphEquHist;
	histogram = calcHist(equalImg);
	graphEquHist = drawMyHist(histogram);
	namedWindow("My Equalized Histogram", CV_WINDOW_AUTOSIZE);
	imshow("My Equalized Histogram", graphEquHist);
	waitKey(0);
	cvDestroyWindow("My Equalized Histogram");
	//imwrite("Saalfeld_AHM_Equalized_Histogram.jpg", graphEquHist );
	return equalBGR;
}

Mat opencvEqual(Mat I) {

	//Split Y Cb Cr planes
	vector<Mat> ycc_planes;
	split(I, ycc_planes);

	//Equalize histogram on Y channel
	equalizeHist(ycc_planes[0], ycc_planes[0]); 
	
	//Merge equalized Y channel with other 2 channel (CrCb)
	Mat equalized_ycc;
	merge(ycc_planes,equalized_ycc);

	//Draw Histogram with OpenCV funtions
	namedWindow("OpenCv Equalized Intensity Histogram", CV_WINDOW_AUTOSIZE );
	imshow("OpenCv Equalized Intensity Histogram", opencvHist(equalized_ycc));
	waitKey(0);
	cvDestroyWindow("OpenCv Equalized Intensity Histogram");
	//imwrite( "Saalfeld_OpenCV_Equalized_Histogram.jpg", opencvHist(equalized_ycc) );

	//Convert YCrCb to BGR
	Mat equalized;
	cvtColor(equalized_ycc, equalized, CV_YCrCb2BGR);

	return equalized;
}

Mat calcHistAHM(Mat I) {

	//Initialize Mat type Histogram matrix shich stores number of times that indexed pixel value occurs in the image.
	Mat	histogram = Mat::zeros(1, 256, CV_32SC1);
	
	int nRows = I.rows;
	int nCols = I.cols;

	// Calculate histogram
	for (int i = 0; i < nRows; i++) {
		for (int j = 0; j < nCols; j++) {
			histogram.at<int>(I.at<uchar>(i,j)) += 1;
		}
	}

	return histogram;
}

void HistEquAHM(Mat blockImage, int *cum) {

	//Find intesity values
	Mat histogram;
	histogram = calcHistAHM(blockImage);

	//Find probability values for each pixel value
	int nRows = blockImage.rows;
	int nCols = blockImage.cols;
	int imageSize = nRows * nCols;

	double prob[256];
	for(int i=0; i<256; i++) {
		prob[i] = (double) histogram.at<int>(i) / imageSize;
	}

	//Find cumulative probabilities
	int cumuPoss[256];
	cumuPoss[0] = histogram.at<int>(0);
	for(int i=1; i<256; i++) {
		cumuPoss[i]= histogram.at<int>(i) + cumuPoss[i-1];
	}
	//Scale cumulative values. scaleVal = (K - 1) / M * N
	double scaleVal = (double) 255/(nRows * nCols);
	int scaledCum[256];
	for(int i=0; i<256; i++) {
		scaledCum[i] = cvRound((double)cumuPoss[i] * scaleVal); // scaling (finding Sk values)
	}

	for(int i=0; i<256; i++){
		cum[i] = scaledCum[i];
	}
}

void AHM(Mat I, int blockSize){
	
	//Check blockSize to be odd number
	if (blockSize % 2 == 0){
		blockSize = blockSize + 1;
	}
	
	Mat	blockImage = Mat::zeros(blockSize, blockSize, CV_8UC1);
	int nRows = I.rows;
	int nCols = I.cols;
	Mat ahmImg = I.clone();
	int rowofBlock = nRows / blockSize;
	int colofBlock= nCols / blockSize;

	//  Allocate 3D Array for Cumulative Map for each block
	int ***cumuMap;
	cumuMap = new int**[rowofBlock];
	for(int i = 0; i < rowofBlock; i++){
		cumuMap[i] = new int*[colofBlock];
		for(int j = 0; j < colofBlock; j++){
			cumuMap[i][j] = new int[256];
		}
	}

	int tmp[256];
	//Calculate cumulative values for each block
	int xImg;
	int yImg;
	for(int i = 0; i < rowofBlock; i++){
		for(int j = 0; j < colofBlock; j++){
			for(int x = 0; x < blockSize; x++){
				for(int y = 0; y < blockSize; y++){
					xImg = blockSize * i + x;
					yImg = blockSize * j + y;
					blockImage.at<uchar>(x,y) = I.at<Vec3b>(xImg,yImg)[0];
				}
			}
			//Find intesity values
			HistEquAHM(blockImage,tmp);
			for (int k = 0; k < 255; k++){
				cumuMap[i][j][k] = tmp[k];
			}
		}
	}

	int rowUpBorder = (blockSize / 2) + 1;
	int rowDownBorder = ((rowofBlock * blockSize) - (blockSize / 2)) - 1;
	int colLeftBorder = ((colofBlock * blockSize) - (blockSize / 2)) - 1;

	int tile_x;
	int tile_y;
	int tile_xup;
	int tile_xdown;
	int tile_yleft;
	int tile_yright;

	int tileULX;
	int tileURX;
	int tileLLX;
	int tileLRX;

	int tileULY;
	int tileURY;
	int tileLLY;
	int tileLRY;

	int centerULX;
	int centerURX;
	int centerLLX;
	int centerLRX;

	int centerULY;
	int centerURY;
	int centerLLY;
	int centerLRY;

	int x2_x1;
    int x2_x;
    int y2_y1;
    int y2_y;
    int x_x1;
    int y_y1;

	int fQ11;
    int fQ12;
	int fQ21;
	int fQ22;

	for(int i = rowUpBorder; i < rowDownBorder; i++){
		for(int j = rowUpBorder; j < colLeftBorder; j++){
			//find 4 neighbor tile's center
			tile_x = (i+1) / blockSize;
			tile_y = (j+1) / blockSize;

			if (((i+1) % blockSize) <= ((blockSize + 1) / 2)) {
				tile_xup = tile_x ;
				tile_xdown = tile_x + 1;
			}
			else{
				tile_xup = tile_x + 1;
				tile_xdown = tile_x + 2;
			}

			if (((j+1) % blockSize) <= ((blockSize + 1) / 2)) {
				tile_yleft = tile_y;
				tile_yright = tile_y + 1;
			}
			else{
				tile_yleft = tile_y + 1;
				tile_yright = tile_y + 2;
			}

			tileULX = tile_xup;
			tileURX = tile_xup;
			tileLLX = tile_xdown;
			tileLRX = tile_xdown;

			tileULY = tile_yleft;
			tileURY = tile_yright;
			tileLLY = tile_yleft;
			tileLRY = tile_yright;

			centerULX = ((tileULX - 1) * blockSize + (blockSize + 1) / 2) - 1;
			centerULY = ((tileULY - 1) * blockSize + (blockSize + 1) / 2) - 1;

            centerURX = ((tileURX - 1) * blockSize + (blockSize + 1) / 2) - 1;				
			centerURY = ((tileURY - 1) * blockSize + (blockSize + 1) / 2) - 1;

			centerLLX = ((tileLLX - 1) * blockSize + (blockSize + 1) / 2) - 1;		
			centerLLY = ((tileLLY - 1) * blockSize + (blockSize + 1) / 2) - 1;

			centerLRX = ((tileLRX - 1) * blockSize + (blockSize + 1) / 2) - 1;
			centerLRY = ((tileLRY - 1) * blockSize + (blockSize + 1) / 2) - 1;


			// Get the value in the bilinear equation.
            x2_x1 = centerLLX - centerULX;
            x2_x = centerLLX - i;
            y2_y1 = centerURY - centerULY;
            y2_y = centerURY - j;
            x_x1 = i - centerULX;
            y_y1 = j - centerULY;

			//equalImg.at<Vec3b>(y,x)[0] = saturate_cast<uchar>(scaledCum[ycc.at<Vec3b>(y,x)[0]]);

			fQ11 = saturate_cast<uchar>(cumuMap[tile_xup - 1][tile_yleft - 1][I.at<Vec3b>(i,j)[0]]);
			fQ12 = saturate_cast<uchar>(cumuMap[tile_xup - 1][tile_yright - 1][I.at<Vec3b>(i,j)[0]]);
			fQ21 = saturate_cast<uchar>(cumuMap[tile_xdown - 1][tile_yleft - 1][I.at<Vec3b>(i,j)[0]]);
			fQ22 = saturate_cast<uchar>(cumuMap[tile_xdown - 1][tile_yright - 1][I.at<Vec3b>(i,j)[0]]);
			
			ahmImg.at<Vec3b>(i,j)[0] = saturate_cast<uchar>(fQ11 * x2_x * y2_y / (x2_x1 * y2_y1) + \
                fQ21 * x_x1 * y2_y /( x2_x1 * y2_y1) + \
                fQ12 * (x2_x) * (y_y1) /(x2_x1 * y2_y1) + \
                fQ22 * (x_x1) * (y_y1) / (x2_x1 * y2_y1));
		}
	}


	Mat ahmImg_BGR;
	ahmImg_BGR = myHistEqu(ahmImg);
	cvtColor(ahmImg, ahmImg_BGR, CV_YCrCb2BGR);
	namedWindow("AHM Equalized Image", CV_WINDOW_AUTOSIZE );
	imshow("AHM Equalized Image", ahmImg_BGR);
	waitKey(0);
	cvDestroyWindow("AHM Equalized Image");
	//imwrite( "Saalfeld_AHM_Equalized_Image.jpg", ahmImg_BGR );

	//Free memory
	for(int i = 0; i < rowofBlock; i++)
	{
		for(int j = 0; j < colofBlock; j++)
		{
			free (cumuMap[i][j]);
		}
		free (cumuMap[i]);
	}
	free(cumuMap);
}

int main()
{
	String imageName = "Saalfeld.jpg";
	String fileName = "Saalfeld";
	//String imageName = "flower.jpg";
	Mat img = readImage(imageName);
	namedWindow( "Source BGR Image", WINDOW_AUTOSIZE );// Create a window for display.
	imshow( "Source BGR Image", img ); // Show our image inside it.
	waitKey(0); // Wait for a keystroke in the window
	cvDestroyWindow("Source BGR Image");

	// ##############        QUESTION 1 BEGIN    ###################

	Mat imgYCC = convertToYCC (img);
	namedWindow( "YCbCr converted image", WINDOW_AUTOSIZE );
	imshow("YCbCr converted image",imgYCC);
	waitKey(0);
	cvDestroyWindow("YCbCr converted image");
	//imwrite( fileName+"_YCbCr.jpg", imgYCC );

	// ##############        BOX FILTERS         ###################

	//Apply 3x3 Box filter
	Mat I_S = myBoxFilter(imgYCC,3);
	namedWindow( "3x3 Box Filtered BGR Image", WINDOW_AUTOSIZE );
	imshow("3x3 Box Filtered BGR Image",I_S);
	waitKey(0);
	cvDestroyWindow("3x3 Box Filtered BGR Image");
	//imwrite( fileName+"_3x3_Box_Filter.jpg", I_S );

	//Apply 5x5 Box filter
	I_S = myBoxFilter(imgYCC,5);
	namedWindow( "5x5 Box Filtered BGR Image", WINDOW_AUTOSIZE );
	imshow("5x5 Box Filtered BGR Image",I_S);
	waitKey(0);
	cvDestroyWindow("5x5 Box Filtered BGR Image");
	//imwrite( fileName+"_5x5_Box_Filter.jpg", I_S );

	//Apply 7x7 Box filter
	I_S = myBoxFilter(imgYCC,7);
	namedWindow( "7x7 Box Filtered BGR Image", WINDOW_AUTOSIZE );
	imshow("7x7 Box Filtered BGR Image",I_S);
	waitKey(0);
	cvDestroyWindow("7x7 Box Filtered BGR Image");
	//imwrite( fileName+"_7x7_Box_Filter.jpg", I_S );

	// ##############        MEDIAN FILTERS         ###################

	//Apply 3x3 Median Filter
	I_S = myMedianFilter(imgYCC,3);
	namedWindow( "3x3 Median Filtered BGR Image", WINDOW_AUTOSIZE );
	imshow("3x3 Median Filtered BGR Image",I_S);
	waitKey(0);
	cvDestroyWindow("3x3 Median Filtered BGR Image");
	//imwrite( fileName+"_3x3_Median_Filter.jpg", I_S );

	//Apply 5x5 Median Filter
	I_S = myMedianFilter(imgYCC,5);
	namedWindow( "5x5 Median Filtered BGR Image", WINDOW_AUTOSIZE );
	imshow("5x5 Median Filtered BGR Image",I_S);
	waitKey(0);
	cvDestroyWindow("5x5 Median Filtered BGR Image");
	//imwrite( fileName+"_5x5_Median_Filter.jpg", I_S );

	//Apply 7x7 Median Filter
	I_S = myMedianFilter(imgYCC,7);
	namedWindow( "7x7 Median Filtered BGR Image", WINDOW_AUTOSIZE );
	imshow("7x7 Median Filtered BGR Image",I_S);
	waitKey(0);
	cvDestroyWindow("7x7 Median Filtered BGR Image");
	//imwrite( fileName+"_7x7_Median_Filter.jpg", I_S );

	// ##############        QUESTION 1 END    ###################


	// ##############        QUESTION 2 BEGIN  ###################

	//Find intensity histogram with my implementation
	namedWindow("My Intensity Histogram", CV_WINDOW_AUTOSIZE );
	Mat hist = calcHist(imgYCC);
	imshow("My Intensity Histogram", drawMyHist(hist));
	waitKey(0);
	cvDestroyWindow("My Intensity Histogram");
	//imwrite( fileName+"_My_Intensity_Histogram.jpg", drawMyHist(hist) );

	//Find intensity histogram with OpenCV functions
	namedWindow("OpenCv Intensity Histogram", CV_WINDOW_AUTOSIZE );
	imshow("OpenCv Intensity Histogram", opencvHist(imgYCC));
	waitKey(0);
	cvDestroyWindow("OpenCv Intensity Histogram");
	//imwrite( fileName+"_OpenCV_Intensity_Histogram.jpg", opencvHist(imgYCC) );

	//Histogram Equalization with my own implementation 
	namedWindow("My Equalized Image", CV_WINDOW_AUTOSIZE );
	imshow("My Equalized Image", myHistEqu(imgYCC));
	waitKey(0);
	cvDestroyWindow("My Equalized Image");
	//imwrite( fileName+"_My_Equalized_Image.jpg", myHistEqu(imgYCC) );

	//Histogram Equalization with my OpenCV functions 
	namedWindow("OpenCV Equalized Image", CV_WINDOW_AUTOSIZE );
	imshow("OpenCV Equalized Image", opencvEqual(imgYCC));
	waitKey(0);
	cvDestroyWindow("OpenCV Equalized Image");
	//imwrite(fileName+"_OpenCV_Equalized_Image.jpg", myHistEqu(imgYCC) );

	// ##############        QUESTION 2 END  ###################


	// ##############        QUESTION 3 BEGIN  ###################
	
	AHM (imgYCC,20);

	// ##############        QUESTION 3 END  ###################

	getchar();
	return 0;
}